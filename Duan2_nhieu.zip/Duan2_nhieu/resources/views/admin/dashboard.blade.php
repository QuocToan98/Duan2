@extends('admin_layout');
@section('admin_content');
<h2>Admin</h2>
@endsection