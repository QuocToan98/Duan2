<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Danhmuc extends Model
{
    protected $table = 'danhmuc';
    protected $primaryKey = 'ma_dm';

}
