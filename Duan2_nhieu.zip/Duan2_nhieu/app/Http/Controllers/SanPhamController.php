<?php

namespace App\Http\Controllers;

// use App\danhmuc;
use App\sanpham;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class SanPhamController extends Controller
{
    function showsanpham($ma_sp)
{
    $showdm = DB::table('danhmuc')->get();
    $showsp = DB::table('sanpham')
        ->leftJoin('danhmuc', 'sanpham.ma_dm', '=', 'danhmuc.ma_dm')
        ->where('ma_sp', $ma_sp)
        ->get();
    return view('shop-single', ['showdm' => $showdm, 'showsp' => $showsp]);
}





    // thêm sản phẩm
    function themsp(Request $Request)
    {

        $showdm = DB::table('danhmuc')->get();

        $tensp = $Request->tensp;
        $giasp =  $Request->giasp;
        $motasp = $Request->motasp;
        $hinhanhsp = $Request->hinhanhsp;
        $danhmucsp = $Request->danhmucsp;


        $sp = new Sanpham;
        $sp->ten_sp = $tensp;
        $sp->gia_sp = $giasp;
        $sp->mota_sp = $motasp;
        if ($Request->hasFile('hinhanhsp')) {
            $now = date("Ymd-His");
            $hinhanhsp = "hinh" . $now . ".jpg";
            $file = $Request->file('hinhanhsp');
            $file->move('images', $hinhanhsp);
            $sp->hinhanh_sp = ('images/' . $hinhanhsp);

        }
        $sp->ma_dm = $danhmucsp;
        $sp->save();

        $listsp = Sanpham::orderBy('ma_sp', 'desc')->get();
return $listsp;
        return view('admin/admin-sp', ['listsp' => $listsp, 'showdm' => $showdm]);
        // }
    }
    // xóa sản phẩm
    function xoasp($ma_sp)
    {
        // return $ma_sp;
        $showdm = DB::table('danhmuc')->get();
        $sp = Sanpham::find($ma_sp);
        // return $sp;
        $sp->delete();
        $listsp = Sanpham::orderBy('ma_sp', 'desc')->get();

        return view('admin/admin-sp', ['listsp' => $listsp, 'showdm' => $showdm]);
    }
    // chỉnh sửa sản phẩm
    function chinhsuasp($ma_sp)
    {
        $showdm = DB::table('danhmuc')->get();
        $infon = Sanpham::find($ma_sp);

        $listsp = Sanpham::orderBy('ma_sp', 'desc')->get();

        return view('admin/admin-sp', ['listsp' => $listsp, 'infon' => $infon, 'showdm' => $showdm]);
    }

    // cập nhập sản phẩm
    function capnhatsp(Request $Request)
    {
        $showdm = DB::table('danhmuc')->get();

        $ma_sp = $Request->masp;
        $ten_sp = $Request->tensp;
        $mota_sp = $Request->motasp;
        // $hinhanh_sp=$Request->hinhanhsp;
        if ($Request->hasFile('hinhanhsp')) {
            $now = date("Ymd-His");
            $hinhanh_sp = "hinh" . $now . ".jpg";
            $file = $Request->file('hinhanhsp');
            $file->move('imgupload', $hinhanh_sp);
            // $sp->hinhanh_sp=$hinhanh_sp;
            // $sp->save();
        }
        $sp_cate = $Request->danhmucsp;
        // echo "hihi".$danhmuc_name;
        $sp = Sanpham::find($ma_sp);
        // $cate->ma_dm=$ma_dm;
        $sp->ten_sp = $ten_sp;
        $sp->mota_sp = $mota_sp;
        $sp->hinhanh_sp = $hinhanh_sp;
        $sp->ma_dm = $sp_cate;
        $sp->save();
        $listsp = Sanpham::orderBy('ma_sp', 'desc')->get();

        return view('admin/admin-sp', ['listsp' => $listsp, 'showdm' => $showdm]);
    }
}




