<?php

namespace App\Http\Controllers;

use App\danhmuc;
use App\sanpham;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class DanhMucController extends Controller
{
    function showdanhmuc($ma_dm)
    {
        $showdm = DB::table('danhmuc')->get();
        $showdmid = DB::table('sanpham')
            ->where('ma_dm', $ma_dm)
            ->get();
        return view('shopdm', ['showdm' => $showdm, 'showdmid' => $showdmid]);
    }



// thêm danh mục
function themdanhmuc(Request $Request)
// function AddCategory(Request $Request)
{

    $validate = Validator::make(
        $Request->all(),
        [
            'catename' => 'required|min:2|max:50',
        ],
        [
            'required' => ':attribute không được bỏ trống <br>',
            'min' => ':attribute tên danh mục quá ít <br>',
            'max' => ':attribute tên danh mục quá dài <br>',
        ],
        [
            'catename' => 'Tên danh mục',
        ]
    );

    if ($validate->fails()) {
        $catename = $Request->catename;
        $infocate = array($catename);
        $listcate = Danhmuc::orderBy('ma_dm', 'desc')->get();

        return view('admin/admin-dm', ['infocate' => $infocate, 'listcate' => $listcate])->withErrors($validate);
    } else {
        $catename = $Request->catename;
        $cate = new Danhmuc;
        $cate->ten_dm = $catename;
        $cate->save();
        $listcate = Danhmuc::orderBy('ma_dm', 'desc')->get();

        return view('admin/admin-dm', ['listcate' => $listcate]);
    }
}
// xóa danh mục
function xoadanhmuc($cate_id)
{
    Sanpham::where('ma_dm', $cate_id)->delete();
    $cate = Danhmuc::find($cate_id);
    $cate->delete();
    $listcate = Danhmuc::orderBy('ma_dm', 'desc')->get();

    return view('admin/admin-dm', ['listcate' => $listcate]);
}
// chỉnh sửa danh mục
function chinhsuadanhmuc($cate_id)
{
    $infoct = Danhmuc::find($cate_id);
    $listcate = Danhmuc::orderBy('ma_dm', 'desc')->get();

    return view('admin/admin-dm', ['listcate' => $listcate, 'infoct' => $infoct]);
}

// cập nhập danh mục
function capnhatdanhmuc(Request $Request)
{
    $ma_dm = $Request->cateid;
    $ten_dm = $Request->catename;
    // echo "hihi".$ten_dm;
    $cate = Danhmuc::find($ma_dm);
    // $cate->ma_dm=$ma_dm;
    $cate->ten_dm = $ten_dm;
    $cate->save();
    $listcate = Danhmuc::orderBy('ma_dm', 'desc')->get();

    return view('admin/admin-dm', ['listcate' => $listcate]);
}

}
