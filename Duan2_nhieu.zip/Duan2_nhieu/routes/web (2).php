<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
use App\Danhmuc;
use App\Sanpham;
Route::get('/', function () {
    $showdm = DB::table('danhmuc')->get();
    $showsp = DB::table('sanpham')->get();
    return view('home', ['showdm' => $showdm, 'showsp' => $showsp, 'page' => "/"]);
});

Route::get('/contact', function () {
    $showdm = DB::table('danhmuc')->get();
    return view('contact', ['showdm' => $showdm, 'page' => "contact"]);
});

Route::get('/about', function () {
    $showdm = DB::table('danhmuc')->get();
    return view('about', ['showdm' => $showdm, 'page' => "about"]);
});

Route::get('/cart', function () {
    return view('cart');
});

Route::get('/checkout', function () {
    return view('checkout');
});


// Route::get('/shop-single', function () {
//     $showdm = DB::table('danhmuc')->get();
//     $showsp = DB::table('sanpham')->get();
//     return view('shop-single', ['showdm' => $showdm, 'showsp' => $showsp, 'page' => "shop-single"]);
// });

Route::get('/shop', function () {
    $showdm = DB::table('danhmuc')->get();
    $showsp = DB::table('sanpham')->get();
    return view('shop', ['showdm' => $showdm, 'showsp' => $showsp, 'page' => "shop"]);
});

Route::get('/shopdm', function () {
    $showdm = DB::table('danhmuc')->get();
    $showsp = DB::table('sanpham')->get();
    return view('shopdm', ['showdm' => $showdm, 'showsp' => $showsp, 'page' => "shopdm"]);
});

// trang danh mục theo id
Route::get('/shopdm/{ma_dm}', 'DanhMucController@showdanhmuc');


// trang chi tiết sản phẩm
Route::get('/shop-single/{ma_sp}', 'SanPhamController@showsanpham');


route::post('logined', 'ContactController@getlienhe');

Route::get('/abc', function () {
    $ketqua = DB::select('select * from sanpham');
    return view('abc', ['ketqua' => $ketqua]);
});


///////////////////////////////////////////////
///////////////////////////////////////////////
////////////////////ADMIN//////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////

// trang chủ admin
Route::get('/admin', function () {
    return view('admin/index', ['page' => "admin"]);
});
// trang đăng nhập admin
Route::get('/login-admin', function () {
    return view('admin/login', ['page' => "login"]);
});
// tab danh mục
Route::get('/admin/category', function () {
    $listcate = Danhmuc::orderBy('ma_dm', 'desc')->get();
    return view('admin/admin-dm', ['page' => "danhmuc", 'listcate' => $listcate]);
});
// tab sản phẩm
Route::get('/admin/news', function () {
    $showdm = DB::table('danhmuc')->get();
    $listsp = Sanpham::orderBy('ma_sp', 'desc')->join('danhmuc', 'danhmuc.ma_dm', '=', 'sanpham.ma_dm')->get();
    // return $listsp;
    return view('admin/admin-sp', ['showdm' => $showdm, 'page' => "news", 'listsp' => $listsp ]);
});

///////////////////////////////////////////////
/////////////XỮ LÝ FORM DANH MỤC///////////////
///////////////////////////////////////////////


// thêm danh mục
Route::post('admin/category-add', 'DanhMucController@themdanhmuc');
// xóa danh mục
Route::get('admin/category-delete/{cate_id}', 'DanhMucController@xoadanhmuc');
// chỉnh sửa danh mục
Route::get('admin/category-updf/{cate_id}', 'DanhMucController@chinhsuadanhmuc');
// cập nhập danh mục
Route::post('admin/category-update', 'DanhMucController@capnhatdanhmuc');




///////////////////////////////////////////////
/////////////XỮ LÝ FORM SẢN PHẨM////////////////
///////////////////////////////////////////////



// check form sản phẩm
Route::post('admin/newssubmit', 'SanPhamController@CheckNews');

// thêm sản phẩm
Route::post('admin/news-add', 'SanPhamController@themsp');
// xóa sản phẩm
Route::get('admin/news-delete/{news_id}', 'SanPhamController@xoasp');
// chỉnh sửa sản phẩm
Route::get('admin/news-updf/{news_id}', 'SanPhamController@chinhsuasp');
// cập nhập sản phẩm
Route::post('admin/news-update', 'SanPhamController@capnhatsp');





///////////////////////////////////////////////
////////////////            ///////////////////
//////////////// TEST MODEL ///////////////////
////////////////            ///////////////////
///////////////////////////////////////////////

Route::get('model/save', function () {
    $user = new App\User();
    $user->name = "Lăng Chí Nhiều";
    $user->email = "langchinhieu@gmail.com";
    $user->password = "7510406nhieu";

    $user->save();

    echo "Đã thực hiện thêm người dùng mới";
});




